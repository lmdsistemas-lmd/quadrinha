# Estado técnico e arquitetura

## Identificação e fonte de verdade

- Repositório de trabalho: `lmdsistemas-lmd/quadrinha`, branch `main`, snapshot de aplicação `b086505`.
- Stack: Node 24.18.0; ESM `.mjs`; HTTP nativo; SQLite nativo `node:sqlite`; frontend sem framework; Nodemailer com lockfile.
- O projeto próprio não é uma modificação do REA. O usuário citou inicialmente `morluto/rea`; o ambiente começou associado a `lmdsistemas-lmd/reamy`. O destino aceito para a aplicação foi depois `lmdsistemas-lmd/quadrinha`.
- Código existente deve prevalecer sobre descrição histórica desatualizada. `docs/PLATAFORMA.md` descreve o SaaS atual. `docs/BANCO-OPERACIONAL.md` e parte de `docs/MERCADO-PAGO.md` documentam principalmente o standalone anterior, com aviso inicial de escopo.
- A exportação não contém os bancos ativos nem serviços externos configurados. O estado funcional abaixo é implementação e testes, não uma migração de produção.

## Três áreas obrigatórias

| Área | Principal | Identidade e permissão | Dinheiro |
| --- | --- | --- | --- |
| Proprietário da plataforma | `/admin` | `accounts.superadmin`, criado por CLI local | Assinaturas da plataforma em sua conta Mercado Pago |
| Proprietário da arena e equipe | `/conta`, `/app/{slug}` | Conta de plataforma + `memberships` por tenant, papel Administrador/Atendente/Consulta | Reserva/serviços da arena em sua própria conta Mercado Pago |
| Jogador/cliente final | `/reservar/{slug}` | Conta `kind=customer`, vinculada à arena, sessão própria | Paga apenas reservas próprias àquela arena |

O superadministrador não tem acesso automático à operação das arenas. Qualquer associação de gestão precisa da permissão de empresa. A conta de jogador não pode consumir a API do dono das quadras. Bloqueio da empresa afeta sessões já existentes e o portal; webhooks financeiros continuam roteados para conciliar transações em andamento.

## Entrada do servidor e integração dos motores

`platform.mjs` exporta `createPlatform(options)` e é o entrypoint de `npm start`. Abre o store mestre e um motor de cobrança da plataforma. Motores de arena são criados sob demanda e cacheados por UUID.

`server.mjs` exporta `createApp(options)` e mantém a aplicação anterior de uma única arena. No SaaS, `managedAuth` e `managedUsers` são callbacks internos: o hub valida a sessão central, provisiona o usuário local com o papel correto e passa a identidade por `WeakMap` da requisição. Não são cabeçalhos HTTP que o navegador pode forjar. Rotas locais de setup/login são bloqueadas nesse modo. O handler HTTP do motor é chamado internamente após ajustar o caminho da requisição; ele não precisa escutar outra porta.

O frontend de gestão identifica o prefixo `/app/{slug}` para enviar chamadas para `/app/{slug}/api`. Downloads de relatório também usam esse prefixo. Manter isso ao alterar frontend/roteamento para não misturar APIs de empresas.

## Arquivos e responsabilidades

| Arquivo | Responsabilidade |
| --- | --- |
| `platform.mjs` | Roteamento, autorização, gestão de acesso central, cobrança de assinatura, configuração por arena e delegação ao motor |
| `platform-store.mjs` | Master SQLite, contas, sessões, tokens, memberships, planos, portais, convites, auditoria e links de e-mail |
| `platform-security.mjs` | Validação, scrypt, hashing, AES-GCM, JSON limitado, cookies/cabeçalhos/origem |
| `integrations.mjs` | Configuração privada por escopo, fila SMTP e WhatsApp Business Platform |
| `server.mjs` | Registros, relações, recorrências, horários/conflitos, estoque, relatórios e auth standalone |
| `payments.mjs` | Schema financeiro, readiness, preferências Checkout Pro, validação de HMAC e conciliação |
| `public-booking.mjs` | Grade pública, associação jogador/cliente local, idempotência de reservas, checkout restrito ao dono da reserva |
| `modules.mjs` | Definições dos módulos e campos; referências, selects, contratos de formulários e funções comuns |
| `dashboard-data.mjs` | Fórmulas e agrupamentos dos indicadores |
| `public/app.js` | Aplicação de gestão com menus/formulários de referência |
| `public/reference-ui.mjs`, `reference.css`, `dashboard*` | Perfis de telas, navegação e fidelidade visual |
| `public/platform-ui.js`, `platform.html`, `platform.css` | Landing, planos, auth, admin, conta e portal do jogador |
| `public/tenant-view.mjs` | Configuração Mercado Pago, WhatsApp, portal, compras, cartões hospedados, indicações e avisos de escopo |
| `scripts/platform-admin.mjs` | Cria superadministrador em terminal interativo, ocultando a senha |
| `scripts/operational-database.mjs` | Criação segura do banco operacional standalone, sem sobrescrita nem dados fictícios |
| `tests/*.test.mjs` | Testes da API, regras, isolamento, finanças, permissões e persistência |
| `scripts/validate-*-browser.mjs` | Fluxos Chromium com banco temporário e provedores de teste |

## Dados e migrações

SaaS em `PLATFORM_DATA_DIR`, padrão `data/platform/`:

1. `platform.sqlite`: identidades, empresas, memberships, planos, assinaturas, configurações privadas e ligações do portal.
2. `platform-billing.sqlite`: cobranças/recebimentos das assinaturas; usa o motor de uma empresa internamente.
3. `tenants/{uuid}.sqlite`: um banco por arena. O caminho é derivado do UUID interno, nunca do slug arbitrário de entrada.
4. `platform.key`: chave privada estável AES, criada com `0600` se não houver `PLATFORM_ENCRYPTION_KEY`.

Standalone anterior: `data/quadrafacil.sqlite`; standalone operacional: `data/operacional.sqlite`. Não houve migração automática para o mestre SaaS. O script `db:operational` copia somente usuários locais do banco anterior quando disponível e nunca substitui o destino. Ele não é uma migração para multiempresa.

Master: `accounts`, `tenants`, `memberships`, `auth_sessions`, `auth_tokens`, `rate_limits`, `plans`, `subscription_charges`, `portal_settings`, `customer_links`, `public_bookings`, `platform_audit`, `notifications`, `referrals`, `integrations`, `mail_outbox`, `whatsapp_messages`.

Motor de empresa: `records`, `users`, `settings`, `audit`, `reports`, `schema_migrations`, `invoices`, `provider_payments`, `payment_events`, `webhook_receipts`, `sessions`. Os cadastros ainda usam JSON em `records`, com validação e relações no servidor; não afirmar que tudo foi normalizado em tabelas por entidade.

Os arquivos `SCHEMA_MASTER.sql` e `SCHEMA_EMPRESA.sql` foram extraídos de bancos NOVOS temporários da mesma versão. São documentação de schema, não scripts para substituir um banco existente. A criação/alteração de tabelas atualmente ocorre no startup. Adotar migrações mais formais futuramente exige plano de preservação.

SQLite usa WAL, foreign keys e busy timeout. A aplicação e os arquivos separados foram preparados para uma instância de processo, em disco persistente local. Não há transação SQLite única entre o master e o banco da arena/financeiro da plataforma; ligações de reservas/assinaturas usam identificadores e verificações de recuperação/idempotência. Isso deve ser considerado ao planejar testes de falha entre bancos.

## Autenticação e e-mail

- Superadmin: CLI local, sem bootstrap HTTP público e sem senha padrão; endereço marcado como verificado por ser cadastro local confiável.
- Usuários comuns: senha de 10 a 200 caracteres com scrypt/salt; confirmação de e-mail para entrar.
- Convite de equipe: novo usuário define a própria senha via link. Conta já existente/verificada recebe associação, sem trocar sua senha.
- Sessões centrais duram oito horas, com hash SHA-256 do token e CSRF no SQLite. Cookies HttpOnly/SameSite=Lax, Secure em HTTPS/produção conforme configuração. O standalone tem seus próprios cookies/sessões.
- Cookies do jogador são limitados ao caminho do portal daquela arena.
- Confirmação: token de 24 horas; recuperação/convite: uma hora. Tokens em hash, uso único; nova emissão invalida o token anterior da mesma finalidade. Troca de senha revoga sessões.
- Verificação de origem e CSRF continuam necessárias. O usuário não pediu desativar esses mecanismos.
- SMTP configurado em `/admin`, com TLS implícito 465 ou STARTTLS obrigatório 587/2525. Uma fila durável armazena conteúdo criptografado, tenta novamente a cada minuto, até cinco tentativas por mensagem e apaga o conteúdo após aceite SMTP.
- Aceite SMTP não é prova de entrega na caixa de entrada. Não há confirmação externa de e-mails reais até o estado exportado.

### Sem domínio / APP_PUBLIC_URL

O commit `b086505` permitiu cadastro e links de e-mail sem APP_PUBLIC_URL quando o listener está em `127.0.0.1` ou `::1`. A origem usa endereço/porta REAIS do listener. Não deriva de Host nem X-Forwarded-Host enviados pelo navegador. A porta 0 em testes é resolvida para a porta efetiva.

Uma interface ampla, como `0.0.0.0`, sem URL pública não habilita esse fallback. Links locais devem ser abertos no computador do servidor. SMTP continua necessário. O usuário pode operar cadastros, ativar empresas manualmente e fazer reservas locais sem um domínio. O fallback não habilita Checkout Pro e não registra endereço local como webhook público.

## Planos e assinaturas

Planos de referência anuais, todos iniciam como rascunho:

| ID | Nome | Equivalente mensal | Total anual |
| --- | --- | ---: | ---: |
| start | Quadra Start | 116,91 | 1.402,92 |
| premium | Quadra Premium | 325,41 | 3.904,92 |
| performance | Quadra Performance | 288,21 | 3.458,52 |
| digital | Quadra Digital | 278,91 | 3.346,92 |
| smart | Quadra Smart | 278,91 | 3.346,92 |
| mobile | Quadra Mobile | 269,61 | 3.235,32 |
| connect | Quadra Connect | 269,61 | 3.235,32 |
| web | Quadra Web | 213,81 | 2.565,72 |

Valores em BRL; contratos/charges preservam centavos inteiros e snapshot da versão do plano. Não cobrar apenas o equivalente mensal por um período anual nem anunciar apps nativos/NF como recursos já implementados. Edição administrativa aceita períodos de 1, 3, 6 ou 12 meses e limite de quadras. Limite manual inicial: cinco quadras.

A renovação é uma nova compra pelo Checkout Pro. Não há assinatura recorrente automática via endpoint preapproval. Pagamento aprovado e validado concede período; repetição do webhook não o duplica. Renovação usa a vigência acumulada ou o instante de concessão quando maior. O cálculo limita o dia ao último dia do mês resultante. Refund total/chargeback retira a concessão correspondente; parcial a preserva.

`tenants.access_mode`:

- `manual`: libera por ativação manual.
- `disabled`: bloqueio manual, preservado mesmo se houver pagamento.
- `subscription`: exige `paid_until` vigente.

`/conta` permite ao proprietário acompanhar/contratar mesmo com a gestão desativada. Planos publicados são escolha do administrador, não automaticamente ofertados por estarem no seed.

## Mercado Pago e integridade financeira

- API fixa HTTPS `api.mercadopago.com`, bearer privado somente servidor.
- Credenciais dinâmicas de escopo `platform` ou UUID da arena, criptografadas em `integrations` com AES-GCM. Nenhum fallback para `MERCADOPAGO_*` global no SaaS.
- Conexão validada em `/users/me`, registrando recebedor e ambiente; mudanças de credencial invalidam essa verificação.
- Preferências em `/checkout/preferences`, valor calculado pelo servidor, origem canônica, idempotency key persistida, preferência persistida antes/depois da chamada. Requisição incerta vai para `review` e não gera tentativa cega nova.
- Uma reserva e sua cobrança de agenda apontam à mesma origem canônica. `sourceModule/sourceId` ajudam o portal a localizar a cobrança, inclusive criada por `cobrancas-agenda`.
- Cartão/Pix online no Checkout Pro. Boletos/ATM são excluídos; a disponibilidade real depende da conta e do provedor. Sem dados completos de cartão na aplicação.
- Preferência tem validade de 24 horas. Expirar preferência não libera automaticamente horário na agenda.
- Webhook: HMAC com secret próprio, manifesto de `data.id`, request ID e timestamp; janela de dez minutos. Corpo/query devem corresponder. O sistema consulta `/v1/payments/{id}` e confere referência, centavos, BRL, recebedor, ambiente e datas antes de baixar.
- Evento financeiro deduplicado por dados normalizados; atualização antiga não desfaz estado mais recente. Mediação exige revisão. Segundo pagamento aprovado da mesma fatura exige revisão, sem segunda receita.
- Receita bruta, taxa do vendedor e estornos são lançamentos separados; ajustes repetidos não duplicam entradas. Dados de cartão/pagador completos não são persistidos.
- Pagamento de origem cancelada não reativa a reserva: vai para revisão.
- Origem financeira com checkout é protegida de exclusão/alteração financeira; observações podem mudar sem desfazer conciliação.
- Nome da conta/caixa local não é instrução de transferência bancária. A conta de liquidação é configurada dentro do Mercado Pago.

## Portal de reservas

Arena precisa estar acessível e com portal publicado. Lista somente quadras ativas e online, tarifas avulsas ativas compatíveis com dia/duração/horário e respeita horários de funcionamento e bloqueios de quadras relacionadas. Considera horários futuros de hoje até 90 dias e intervalos de 30 minutos; duração configurável 30/60/90/120 minutos.

Preços e conflitos são revalidados no servidor. Cadastro do jogador é próprio daquela arena; a ligação com `clientes` local é gerada internamente. Reserva usa chave idempotente por jogador/arena e identificador determinístico para recuperação entre master e motor. Repetição da mesma requisição retorna a reserva existente. Reservas de jogadores diferentes não podem ocupar o mesmo intervalo.

Jogador lista/paga apenas reservas próprias. Consulta pública de pagamento não aceita IDs arbitrários de terceiros; aguarda o primeiro vínculo validado para consultar um pagamento já identificado. Notificações de reserva chegam ao painel da arena.

Reservas `Pendente` ocupam o horário e não expiram automaticamente. Cancelamento de checkout, liberação de hold e estorno automático ainda exigem desenvolvimento; não improvisar exclusão local de uma reserva que ainda pode receber um pagamento externo.

## WhatsApp e comunicações

API oficial Meta `graph.facebook.com/v23.0`, por arena: phone number ID, access token, app secret, verify token, nome de template aprovado e idioma. Envio manual usa template sem variáveis, telefone internacional e confirmação de consentimento. Estado inicial `accepted`; entrega/leitura depende de webhook assinado, com número e mensagem vinculados ao escopo correto.

Isso não é integração por QR de WhatsApp Web, chatbot, agendamento de lembretes ou reserva por conversa. O usuário escolheu WhatsApp e SMTP; emissão fiscal ficou fora. SMS, Pagar.me, aplicativos nativos e push ainda não foram implementados nesta etapa. Indicações têm código/atribuição e contador; sem recompensa financeira definida. Cartões são administrados no ambiente hospedado do Mercado Pago, sem cofre próprio de PAN.

## Dashboard e visual

O usuário reclamou especificamente de menus/botões de subpáginas e dashboard. A referência foi observada com autorização, sem gravar dados nela. Recursos públicos de marca/fontes/ícones já estão locais com licenças em docs. Capturas novas do repositório usam dados fictícios.

Há comparações geométricas do cabeçalho do dashboard e de Quadras no Chromium em 1440x1000. Isso não comprova igualdade em todos os pixels, estados ou resoluções. O site original chegou a redirecionar para renovação de plano, limitando a reobservação de telas; não renovar nem contornar automaticamente esse acesso.

O dashboard usa regras próprias documentadas em `docs/DASHBOARD.md`: faturamento, lucro, ocupação, inadimplência, ticket e novos clientes. Usa horários ativos para capacidade e evita receita/pendência duplicada de reserva/cobrança. Gráficos SVG e preferências de navegador são locais. As fórmulas não foram validadas contra o backend original.
