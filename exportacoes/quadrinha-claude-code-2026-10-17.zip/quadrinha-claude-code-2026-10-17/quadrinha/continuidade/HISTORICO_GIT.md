# Histórico Git da aplicação

Extraído do repositório, da criação até o commit-base da exportação. Datas locais em America/Sao_Paulo; mensagens de conversa sem timestamp não receberam essas datas por inferência. O bundle da branch main acompanha o pacote.

## 4cccc76 — feat: add independent Quadra Fácil test application

SHA: `4cccc76daa3fbe7070225d50e44756e27788348a`
Data local: 2026-10-15T18:22:58-03:00

Arquivos modificados:

```text
A	.gitignore
A	.nvmrc
A	AGENTS.md
A	README.md
A	docs/ESCOPO.md
A	docs/agenda-demo.png
A	docs/painel-celular.png
A	docs/painel-demo.png
A	docs/validacao-ui.json
A	modules.mjs
A	package.json
A	public/app.js
A	public/favicon.svg
A	public/index.html
A	public/style.css
A	server.mjs
A	tests/workflows.test.mjs
```

## 39049e9 — fix: serve public files correctly on Windows

SHA: `39049e96d2ccb44276a1b6db495e4285e15f0964`
Data local: 2026-10-15T18:30:42-03:00

Arquivos modificados:

```text
M	README.md
M	server.mjs
M	tests/workflows.test.mjs
```

## cb3729c — feat: align menus, buttons and registration pages with reference

SHA: `cb3729cdf3af0f300b72df3b626dd8261ebffd5b`
Data local: 2026-10-15T19:28:49-03:00

Arquivos modificados:

```text
M	README.md
M	docs/ESCOPO.md
A	docs/FIDELIDADE.md
A	docs/FONT-AWESOME-LICENSE.txt
A	docs/OPEN-SANS-LICENSE.txt
A	docs/agenda-atualizada.png
A	docs/cliente-cadastro-atualizado.png
A	docs/clientes-celular-atualizado.png
A	docs/quadras-atualizado.png
A	docs/validacao-fidelidade.json
M	modules.mjs
M	package.json
M	public/app.js
A	public/assets/ativo.png
A	public/assets/editar.png
A	public/assets/fa-brands-400.woff2
A	public/assets/fa-regular-400.woff2
A	public/assets/fa-solid-900.woff2
A	public/assets/inativo.png
A	public/assets/lixeira.png
A	public/assets/logo-rodape.png
A	public/assets/logo.png
A	public/assets/open-sans-latin-400-normal.woff2
A	public/assets/open-sans-latin-600-normal.woff2
A	public/assets/open-sans-latin-700-normal.woff2
A	public/assets/open-sans-latin-800-normal.woff2
A	public/fontawesome-shims.css
A	public/fontawesome.css
M	public/index.html
A	public/reference-ui.mjs
A	public/reference.css
A	scripts/validate-browser.mjs
M	server.mjs
M	tests/workflows.test.mjs
```

## 3516999 — feat: rebuild dashboard and add operational database with Mercado Pago checkout

SHA: `3516999d95fa701667c0135f34c8dff18efaa7a4`
Data local: 2026-10-17T13:01:18-03:00

Arquivos modificados:

```text
A	.env.example
M	AGENTS.md
M	README.md
A	dashboard-data.mjs
A	docs/BANCO-OPERACIONAL.md
A	docs/DASHBOARD.md
M	docs/ESCOPO.md
M	docs/FIDELIDADE.md
A	docs/MERCADO-PAGO.md
M	docs/agenda-atualizada.png
M	docs/cliente-cadastro-atualizado.png
A	docs/dashboard-atualizado.png
A	docs/dashboard-celular-atualizado.png
A	docs/financeiro-configuracao-homologacao.png
M	docs/quadras-atualizado.png
M	docs/validacao-fidelidade.json
A	docs/validacao-financeiro.json
M	modules.mjs
M	package.json
A	payments.mjs
M	public/app.js
A	public/dashboard-view.mjs
A	public/dashboard.css
A	public/finance-view.mjs
A	public/finance.css
M	public/index.html
M	public/reference-ui.mjs
A	scripts/operational-database.mjs
A	scripts/start-operational.mjs
M	scripts/validate-browser.mjs
A	scripts/validate-finance-browser.mjs
M	server.mjs
A	tests/dashboard.test.mjs
A	tests/payments.test.mjs
```

## d39f4d5 — feat: separate platform, arena management and public booking areas

SHA: `d39f4d559c401c6a93d2621bd8b472dd945aee12`
Data local: 2026-10-17T13:55:51-03:00

Arquivos modificados:

```text
M	.env.example
M	AGENTS.md
M	README.md
M	docs/BANCO-OPERACIONAL.md
M	docs/ESCOPO.md
M	docs/MERCADO-PAGO.md
A	docs/PLATAFORMA.md
A	docs/plataforma-admin.png
A	docs/plataforma-mercadopago-arena.png
A	docs/plataforma-portal-celular.png
A	docs/plataforma-portal-reservas.png
A	docs/validacao-plataforma.json
A	integrations.mjs
A	package-lock.json
M	package.json
M	payments.mjs
A	platform-security.mjs
A	platform-store.mjs
A	platform.mjs
A	public-booking.mjs
M	public/app.js
M	public/finance.css
A	public/platform-ui.js
A	public/platform.css
A	public/platform.html
A	public/tenant-view.mjs
A	scripts/platform-admin.mjs
A	scripts/validate-platform-browser.mjs
M	server.mjs
A	tests/platform.test.mjs
```

## b086505 — fix: allow local registration without a public application URL

SHA: `b08650548ea6cbd02af7707c4cbc7d82385d50c6`
Data local: 2026-10-17T16:10:04-03:00

Arquivos modificados:

```text
M	.env.example
M	README.md
M	docs/PLATAFORMA.md
M	platform-store.mjs
M	platform.mjs
M	public/platform-ui.js
M	tests/platform.test.mjs
```
