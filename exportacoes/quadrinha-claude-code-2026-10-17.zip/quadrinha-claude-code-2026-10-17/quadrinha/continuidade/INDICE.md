# Índice da continuidade

Leia primeiro `../CLAUDE.md` na pasta do projeto e `../CONTINUIDADE_COMPLETA.md` para o documento único.

| Arquivo | Finalidade |
| --- | --- |
| [CONVERSA_DISPONIVEL.md](CONVERSA_DISPONIVEL.md) | Textos disponíveis, respostas finais e síntese identificada das partes antigas |
| [CONVERSA_DISPONIVEL.json](CONVERSA_DISPONIVEL.json) | A mesma conversa em formato estruturado |
| [DECISOES.md](DECISOES.md) | Escolhas do usuário e consequências de implementação |
| [ESTADO_TECNICO.md](ESTADO_TECNICO.md) | Arquitetura, dados, identidade, dinheiro, regras e limites |
| [API_ROTAS.md](API_ROTAS.md) | Rotas, permissões e payloads da API |
| [OPERACAO_E_MIGRACAO.md](OPERACAO_E_MIGRACAO.md) | Rodar, configurar, restaurar Git/dados e sair do ambiente antigo |
| [PENDENCIAS.md](PENDENCIAS.md) | Implementado, dependências externas e evolução sugerida |
| [HISTORICO_GIT.md](HISTORICO_GIT.md) | Os seis commits de aplicação e arquivos alterados |
| [VALIDACAO.json](VALIDACAO.json) | Estado dos testes atuais e distinção de evidências anteriores |
| [MANIFESTO.json](MANIFESTO.json) | Origem, commit e alcance desta documentação |
| [CONTRATOS_MODULOS.json](CONTRATOS_MODULOS.json) | Todos os campos e opções dos 36 módulos e duas configurações |
| [SCHEMA_MASTER.sql](SCHEMA_MASTER.sql) | DDL de documentação do banco mestre |
| [SCHEMA_EMPRESA.sql](SCHEMA_EMPRESA.sql) | DDL de documentação do motor/financeiro |
| [SCHEMA_METADATA.json](SCHEMA_METADATA.json) | Metadados estruturados dos schemas |
| [../evidencias/testes-atual.txt](../evidencias/testes-atual.txt) | Saída do runner atual, 42 testes aprovados |

Os arquivos JSON de decisões/histórico são versões estruturadas dos documentos correspondentes. A raiz do pacote inclui instruções de importação, bundle Git e somas SHA-256. O código está na pasta do projeto, sem credenciais ou bancos privados.
