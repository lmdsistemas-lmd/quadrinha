# Decisões aceitas e consequências

| ID | Decisão | Fonte | Consequência |
| --- | --- | --- | --- |
| D01: Propriedade e referência | O usuário declarou ser proprietário do sistema de referência e pediu uma nova versão própria com mesma aparência e funções. | Mensagens do usuário | Não importar dados reais nem gravar na referência durante observação. |
| D02: Três áreas | Plataforma, dono da arena/equipe e jogador têm acessos e rotas próprios. | Pedido explícito do usuário | Preservar autenticação e autorização no servidor. |
| D03: Separação de dados | Demonstração inicial separada; evolução operacional sem copiar cadastros fictícios nem dados do original. | Decisão do usuário e implementação subsequente | Não apagar bancos para atualizar nem aplicar testes em dados principais. |
| D04: Pagamento online | Cartão e Pix pelo Checkout Pro, sem Point nesta etapa. | Resposta explícita do usuário | Sem PAN no frontend/backend próprio e sem falsa confirmação pelo retorno. |
| D05: Credenciais por recebedor | Cada dono de arena configura sua conta; proprietário da plataforma configura outra para mensalidades. | Pedido explícito do usuário | Isolamento financeiro e criptografia de segredos por escopo. |
| D06: Planos | Oito valores observados são equivalentes mensais de contratação anual; seed é rascunho revisável. | Pedido de copiar valores + evidência da tela e implementação | Cobrar total do período e preservar snapshot/versionamento. |
| D07: Controles centrais | Ativar/desativar empresas, administrar planos e enviar reset de senha por e-mail. | Pedido explícito do usuário | Bloqueio manual não é desfeito por recebimento. |
| D08: Comunicações | SMTP configurável e WhatsApp; sem emissão fiscal por enquanto. | Resposta explícita do usuário | WhatsApp Meta foi escolha técnica implementada, ainda requer conta comercial; sem promessa de robô ou NF. |
| D09: Portal | Arena configura página; cliente final cadastra, verifica e-mail, reserva e paga a própria reserva. | Pedido explícito do usuário | Servidor calcula preço e disponibilidade; sem acesso a reservas alheias. |
| D10: Domínio ausente | Pode operar localmente sem APP_PUBLIC_URL em listener loopback. | Pedido explícito mais recente de comportamento | SMTP continua para verificação; checkout externo continua exigindo HTTPS público. |
| D11: Estado real | Testes passaram com providers substituídos e bancos temporários. | Evidência dos testes e relatórios | Não afirmar homologação externa ou implantação publicada. |
| D12: Continuidade no Claude | Exportar histórico disponível, código e andamento de forma completa e portátil. | Solicitação atual do usuário | Não inventar mensagens faltantes nem transportar credenciais junto da conversa. |
