-- Documentação do schema de uma instalação NOVA temporária.
-- Código-base b086505. Não usar para substituir bancos existentes.
-- Contexto de banco: EMPRESA; os dois schemas pertencem a arquivos distintos.

-- table: audit
CREATE TABLE audit(id INTEGER PRIMARY KEY,time TEXT NOT NULL,actor TEXT NOT NULL,action TEXT NOT NULL,module TEXT NOT NULL,record_id TEXT NOT NULL);

-- table: invoices
CREATE TABLE invoices(
   id TEXT PRIMARY KEY,source_module TEXT NOT NULL,source_id TEXT NOT NULL,
   billing_module TEXT NOT NULL,billing_id TEXT NOT NULL,description TEXT NOT NULL,
   amount_cents INTEGER NOT NULL CHECK(amount_cents>0),currency TEXT NOT NULL CHECK(currency='BRL'),
   account_id TEXT NOT NULL,environment TEXT NOT NULL CHECK(environment IN ('test','production')),
   merchant_id TEXT NOT NULL,status TEXT NOT NULL,preference_id TEXT,checkout_url TEXT,idempotency_key TEXT NOT NULL UNIQUE,
   created_at TEXT NOT NULL,updated_at TEXT NOT NULL,expires_at TEXT NOT NULL,created_by TEXT NOT NULL,
   UNIQUE(source_module,source_id)
  );

-- table: payment_events
CREATE TABLE payment_events(
   id TEXT PRIMARY KEY,invoice_id TEXT REFERENCES invoices(id),payment_id TEXT,
   event_type TEXT NOT NULL,detail TEXT NOT NULL,created_at TEXT NOT NULL,snapshot TEXT NOT NULL DEFAULT '{}'
  );

-- table: provider_payments
CREATE TABLE provider_payments(
   id TEXT PRIMARY KEY,invoice_id TEXT NOT NULL REFERENCES invoices(id),status TEXT NOT NULL,
   amount_cents INTEGER NOT NULL,refunded_cents INTEGER NOT NULL DEFAULT 0,fee_cents INTEGER,
   method TEXT NOT NULL,approved_at TEXT,provider_updated_at TEXT NOT NULL,updated_at TEXT NOT NULL
  );

-- table: records
CREATE TABLE records(id TEXT PRIMARY KEY,module TEXT NOT NULL,data TEXT NOT NULL,created_at TEXT NOT NULL,deleted_at TEXT);

-- table: reports
CREATE TABLE reports(id TEXT PRIMARY KEY,name TEXT NOT NULL,module TEXT NOT NULL,content BLOB NOT NULL,created_at TEXT NOT NULL,record_count INTEGER NOT NULL);

-- table: schema_migrations
CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY,applied_at TEXT NOT NULL);

-- table: sessions
CREATE TABLE sessions(
   token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   csrf TEXT NOT NULL,expires_at INTEGER NOT NULL
  );

-- table: settings
CREATE TABLE settings(key TEXT PRIMARY KEY,data TEXT NOT NULL);

-- table: users
CREATE TABLE users(id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL, created_at TEXT, last_login TEXT);

-- table: webhook_receipts
CREATE TABLE webhook_receipts(
   fingerprint TEXT PRIMARY KEY,payment_id TEXT NOT NULL,received_at TEXT NOT NULL
  );

-- index: provider_payments_invoice
CREATE INDEX provider_payments_invoice ON provider_payments(invoice_id);

-- index: records_module
CREATE INDEX records_module ON records(module,deleted_at);
