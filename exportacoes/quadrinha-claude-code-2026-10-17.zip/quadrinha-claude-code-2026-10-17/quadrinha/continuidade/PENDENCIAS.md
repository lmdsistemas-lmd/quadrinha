# Pendências, limites e próximos passos sugeridos

## Solicitação atual e prioridade

A última solicitação foi exportar conversa e andamento para continuar no Claude Code. A última alteração funcional foi habilitar uso local sem APP_PUBLIC_URL. Não há outra tarefa funcional nova explicitamente escolhida depois disso. A fila abaixo orienta a próxima conversa; não autoriza cobranças reais, envios, publicação ou mudança da arquitetura por iniciativa automática.

## Pronto no código e validado localmente

- Três áreas de acesso, banco por arena e financeiro central separado.
- CRUDs e regras existentes da gestão, dashboard revisado, menus e botões ajustados à referência observada.
- Administração central de empresas, modos de acesso, planos editáveis/publicáveis e recuperação de senha do proprietário.
- Confirmação de e-mail e convites, com tokens de uso único e fila SMTP.
- Mercado Pago Checkout Pro, credenciais por recebedor, preferência, webhook e conciliação financeira.
- Compra/renovação de plano com snapshot e concessão idempotente de período; preservação de bloqueio manual.
- Portal básico, disponibilidade, cadastro do jogador, reserva e checkout próprios.
- Configuração e adaptador de WhatsApp Meta com template manual e confirmação por webhook.
- Uso local sem domínio e sem APP_PUBLIC_URL; preservação de confirmação de e-mail e bloqueio de checkout externo sem HTTPS.

## Implementado, mas falta configuração/homologação externa

| Item | O que falta | Não confundir com |
| --- | --- | --- |
| SMTP | Provedor/host, usuário, senha, remetente, liberação de porta e testes de caixa de entrada | Mensagem aceita por transporte fictício não é e-mail real |
| HTTPS público | Hospedagem ou URL temporária e APP_PUBLIC_URL na publicação | Processo local não é aplicação publicada |
| Mercado Pago da plataforma | Credenciais próprias, assinatura, validação de conta, configuração financeira e webhook | Token de uma arena não recebe assinaturas da plataforma |
| Mercado Pago de cada arena | Credenciais e webhook independentes para cada recebedor | Chave global de ambiente não é fallback SaaS |
| WhatsApp Meta | Conta comercial/app, número/ID, token, app secret, verify token e template aprovado | Número comum de WhatsApp não fornece acesso à API |
| Produção | Volume persistente, gestão/backup de chave, restauração, domínio/proxy e monitoramento | Suíte de testes não certifica operação externa |

Não há confirmação de cobranças, e-mails ou mensagens reais nesta exportação. Os dados de acesso ao site de referência não substituem qualquer requisito acima.

## Melhorias funcionais ainda em aberto

1. **Fidelidade visual completa**: revisar por tela, modal, subaba, estados vazios/erro e dispositivo. O pedido original de aparência idêntica permanece uma meta; as comparações existentes são parciais.
2. **Reservas pendentes/abandono**: definir política de hold, expiração e cancelamento coordenado com preferências/pagamentos. Não liberar o horário enquanto um pagamento pendente ainda puder aprovar sem tratamento de pagamento tardio.
3. **Operação financeira avançada**: cancelamento/estorno iniciado pela aplicação, pagamentos parciais, fechamento, conciliação bancária, parcelamentos e recuperação de respostas incertas. Não basta mudar status no SQLite.
4. **Assinaturas avançadas**: se solicitado, cobrança recorrente automática real, avisos de vencimento, upgrade/downgrade/prorrata, limites de recursos por plano e regras comerciais. Hoje a renovação é compra do período.
5. **Tarifas e agenda**: feriados, pacotes, franquias, rateios, séries editáveis em lote e regras completas não observadas no original.
6. **Aulas**: reserva automática da quadra da turma, geração escolar em lote e assinatura de contratos.
7. **WhatsApp avançado**: templates com variáveis, lembretes agendados, automação de reserva/conversação e controles de custos. Hoje envio manual sem variáveis.
8. **Notificações**: canais push e fluxo avançado de notícias; cadastros de rascunhos não são publicação automática em app nativo.
9. **Relatórios**: PDF/exports adicionais, agendamento e filtros/detalhamentos ainda identificados como pendentes.
10. **Indicações**: definir se haverá recompensa e regras. Não atribuir bônus financeiro ao contador atual.
11. **Apps nativos/SMS/Pagar.me/fiscal**: fora da implementação atual; o usuário escolheu sem emissão fiscal por enquanto. Não reintroduzir fiscal automaticamente por planos da referência citarem NF.

## Evolução técnica a avaliar antes de operação maior

- Planejar migrações versionadas e possíveis tabelas por domínio; cadastros continuam em JSON `records`.
- Considerar falhas entre bancos distintos e recuperação da associação reserva/master e assinatura/financeiro; não há transação distribuída única.
- SQLite/uma instância: avaliar concorrência, cache de motores por arena e custo de varrer listas de registros/faturas antes de escalar.
- Definir monitoramento de fila SMTP e mensagens em revisão, rastreio de conciliação e processo operacional de atendimento.
- Testar backup e restauração incluindo todos os bancos e a chave correta. A exportação não inclui backup privado.
- Revisar gestão/rotação de credenciais com faturas pendentes. Hoje editar credenciais invalida verificação do merchant; conciliação histórica precisa da conta/ambiente corretos.
- Validar no Windows real se esse for o ambiente de destino. Existem testes de caminhos Windows e um reparo do servidor de arquivos, mas as validações de navegador registradas foram Linux/Chromium.
- Uma migração para PostgreSQL, framework de frontend ou ORM deve ser uma decisão explícita de evolução, não pressuposto para retomar no Claude Code.

## Critérios práticos de aceite da próxima entrega

Preservar isolamento e fluxo de dinheiro, cobrir o comportamento novo com testes relevantes, diferenciar mocks de serviços externos e documentar como operar/voltar atrás sem apagar dados. Para mudanças visuais, produzir evidência com dados fictícios e indicar a referência usada. Para publicação, entregar configuração concreta e aguardar os requisitos/autorização correspondentes.
