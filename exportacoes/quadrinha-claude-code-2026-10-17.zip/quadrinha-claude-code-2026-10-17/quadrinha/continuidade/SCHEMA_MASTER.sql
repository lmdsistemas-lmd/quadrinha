-- Documentação do schema de uma instalação NOVA temporária.
-- Código-base b086505. Não usar para substituir bancos existentes.
-- Contexto de banco: MASTER; os dois schemas pertencem a arquivos distintos.

-- table: accounts
CREATE TABLE accounts(id TEXT PRIMARY KEY,kind TEXT NOT NULL,tenant_id TEXT NOT NULL DEFAULT '',name TEXT NOT NULL,email TEXT NOT NULL,password TEXT NOT NULL,verified INTEGER NOT NULL DEFAULT 0,superadmin INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,UNIQUE(kind,tenant_id,email));

-- table: auth_sessions
CREATE TABLE auth_sessions(token_hash TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id),csrf TEXT NOT NULL,expires_at INTEGER NOT NULL);

-- table: auth_tokens
CREATE TABLE auth_tokens(token_hash TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id),purpose TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at TEXT);

-- table: customer_links
CREATE TABLE customer_links(tenant_id TEXT NOT NULL,account_id TEXT NOT NULL,local_id TEXT NOT NULL,PRIMARY KEY(tenant_id,account_id));

-- table: integrations
CREATE TABLE integrations(scope TEXT NOT NULL,provider TEXT NOT NULL,encrypted TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(scope,provider));

-- table: mail_outbox
CREATE TABLE mail_outbox(id TEXT PRIMARY KEY,encrypted TEXT NOT NULL,status TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,last_attempt TEXT);

-- table: memberships
CREATE TABLE memberships(tenant_id TEXT NOT NULL REFERENCES tenants(id),account_id TEXT NOT NULL REFERENCES accounts(id),role TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(tenant_id,account_id));

-- table: notifications
CREATE TABLE notifications(id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,account_id TEXT NOT NULL,title TEXT NOT NULL,content TEXT NOT NULL,read_at TEXT,created_at TEXT NOT NULL);

-- table: plans
CREATE TABLE plans(id TEXT PRIMARY KEY,name TEXT NOT NULL,amount_cents INTEGER NOT NULL,period_months INTEGER NOT NULL,court_limit INTEGER NOT NULL,published INTEGER NOT NULL DEFAULT 0,description TEXT NOT NULL,version INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL);

-- table: platform_audit
CREATE TABLE platform_audit(id INTEGER PRIMARY KEY,actor TEXT NOT NULL,action TEXT NOT NULL,target TEXT NOT NULL,created_at TEXT NOT NULL);

-- table: portal_settings
CREATE TABLE portal_settings(tenant_id TEXT PRIMARY KEY REFERENCES tenants(id),data TEXT NOT NULL);

-- table: public_bookings
CREATE TABLE public_bookings(tenant_id TEXT NOT NULL,account_id TEXT NOT NULL,booking_id TEXT NOT NULL,idempotency_key TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(tenant_id,booking_id),UNIQUE(tenant_id,account_id,idempotency_key));

-- table: rate_limits
CREATE TABLE rate_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires_at INTEGER NOT NULL);

-- table: referrals
CREATE TABLE referrals(code TEXT PRIMARY KEY,tenant_id TEXT NOT NULL UNIQUE,referred_by TEXT);

-- table: subscription_charges
CREATE TABLE subscription_charges(id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL REFERENCES tenants(id),source_id TEXT NOT NULL UNIQUE,plan_snapshot TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending',paid_at TEXT,created_at TEXT NOT NULL);

-- table: tenants
CREATE TABLE tenants(id TEXT PRIMARY KEY,slug TEXT NOT NULL UNIQUE,name TEXT NOT NULL,owner_id TEXT NOT NULL REFERENCES accounts(id),access_mode TEXT NOT NULL DEFAULT 'subscription',paid_until TEXT,created_at TEXT NOT NULL);

-- table: whatsapp_messages
CREATE TABLE whatsapp_messages(id TEXT PRIMARY KEY,scope TEXT NOT NULL,provider_id TEXT UNIQUE,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
