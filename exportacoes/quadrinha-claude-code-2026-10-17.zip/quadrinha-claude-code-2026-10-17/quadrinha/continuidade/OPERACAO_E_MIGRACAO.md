# Operação, instalação e mudança de ambiente

## Instalação nova

Requer Node 24.18.0 (há `.nvmrc`; `package.json` aceita >=24.15.0) e npm compatível com lockfile. Não usar Node antigo sem `node:sqlite`. Não é necessário instalar PostgreSQL, Docker, Redis ou um framework para executar a versão exportada.

No terminal da pasta `quadrinha`:

```bash
node --version
npm ci
npm run check
npm test
```

Em primeira instalação, crie o seu acesso:

```bash
npm run platform:admin
npm start
```

O primeiro comando exige terminal interativo e oculta a senha. Informe credenciais próprias. Não há senha padrão. O comando não deve ser executado automaticamente a cada inicialização. Se já houver acesso, use o fluxo de login/recuperação da instalação correspondente.

Para configuração local, copie `.env.example` para um `.env` privado somente se precisar de ajustes. Este conjunto é suficiente para uso no próprio computador:

```dotenv
APP_PUBLIC_URL=
HOST=127.0.0.1
PORT=3000
NODE_ENV=development
PLATFORM_MODE=production
```

O uso local sem URL não desliga confirmação de e-mail: configure SMTP em `/admin`. Não marque contas comuns como verificadas por SQL para contornar esse requisito. Para testes automatizados, use os transportes/fixtures existentes com bancos temporários.

O modo de produção é padrão e usa banco operacional vazio; isso não significa que cobrança externa já esteja ativada. O painel cria cadastros reais da instalação. Quando houver HTTPS/credenciais, o mesmo conjunto poderá evoluir conforme regras do banco operacional.

Para testes financeiros de homologação, usar OUTRO diretório de dados:

```dotenv
PLATFORM_MODE=test
PLATFORM_DATA_DIR=/caminho/privado/quadrinha-homologacao
```

Não mudar o banco de operação para teste. O marcador operacional impede pagamentos de teste no banco já marcado, mesmo se uma variável for alterada.

## URLs de uso

| Finalidade | Rota relativa |
| --- | --- |
| Landing/planos | `/` e `/planos` |
| Cadastro de dono | `/cadastro` |
| Login da plataforma | `/entrar` |
| Administração central | `/admin` |
| Minhas empresas/assinaturas | `/conta` |
| Gestão da arena | `/app/{slug}` |
| Portal do jogador | `/reservar/{slug}` |
| Consumir link de e-mail | `/acesso` |
| Recuperar senha da plataforma | `/recuperar-senha` |

Acesse usando o host/porta da instalação. Links locais de e-mail devem ser abertos no mesmo computador do servidor. Se o e-mail for aberto pelo celular, o endereço local aponta para o celular e não para o servidor.

## Depois de criar o administrador

1. Configure SMTP no painel central e valide a conexão. Confira a fila.
2. Crie o cadastro do dono de uma arena e confirme seu e-mail.
3. Na administração, ative a empresa manualmente enquanto não usa cobrança online.
4. Na empresa, cadastre quadras, horários, tarifas avulsas e uma conta/caixa.
5. Publique a página em Reserva Online.
6. No portal, o jogador faz cadastro próprio, confirma e-mail e reserva. Sem checkout habilitado, a reserva fica pendente para acompanhamento da arena.
7. Revise preço e recursos e publique os planos que deseja oferecer. Os oito seeds são rascunhos anuais.
8. Ao configurar uma URL pública HTTPS e serviços externos, valide cada recebedor separadamente e o retorno dos webhooks.

## Variáveis e escopos

| Nome | Leitura/uso | Observação |
| --- | --- | --- |
| `APP_PUBLIC_URL` | Origem pública HTTPS | Opcional em listener local; checkout/webhooks exigem origem pública, sem caminho/query/fragmento |
| `HOST` | Interface do listener | Padrão 127.0.0.1; fallback local aceita apenas 127.0.0.1/::1 |
| `PORT` | Porta HTTP | Padrão 3000; links locais usam porta efetiva |
| `PLATFORM_MODE` | production ou test | Padrão production; testes em diretório distinto |
| `PLATFORM_DATA_DIR` | Diretório de dados SaaS | Padrão data/platform; pode conter caminho absoluto |
| `PLATFORM_ENCRYPTION_KEY` | 32 bytes em hexadecimal | Chave privada estável, entregue diretamente ao processo, sem placeholder HTTP |
| `NODE_ENV` | Cookies seguros/configuração | Em HTTPS/produção os cookies devem permanecer seguros |
| `QF_DATABASE_PATH` | Banco standalone | Não é o diretório de dados SaaS |
| `MERCADOPAGO_*` | Apenas fluxo standalone anterior | Não são credenciais globais para todas as arenas SaaS |
| `QF_PLAYWRIGHT_MODULE` | Ferramenta opcional de navegador | Caminho/import do Playwright Core |
| `QF_BROWSER_PATH` | Executável de Chromium/Chrome | Padrão Linux /usr/bin/chromium |

A configuração privada por empresa (MP, WhatsApp) é feita pela interface e armazenada criptografada no master. SMTP é da plataforma. Não inserir valores em `CLAUDE.md`, prompts, arquivos versionados ou `CONTINUIDADE_COMPLETA.md`.

## Testes de navegador

Não são necessários para `npm start` nem `npm test`. O runtime da aplicação só precisa da dependência do lockfile. Para os testes Chromium, instale Playwright Core em diretório de ferramentas separado e use navegador compatível já instalado:

```bash
QF_PLAYWRIGHT_MODULE=/caminho/ferramentas/node_modules/playwright-core/index.mjs QF_BROWSER_PATH=/caminho/chromium npm run test:platform-browser
```

Outras suítes:

```bash
npm run test:browser
npm run test:finance-browser
```

Esses scripts geram/atualizam capturas e resultados em `docs/`. Conferir o diff após rodá-los; uma captura gerada não é comparação automática de todos os pixels. Na máquina original havia Playwright Core em `/workspace/reamy/node_modules/playwright-core/index.mjs` e Chromium em `/usr/bin/chromium`; não presumir esses caminhos em outra máquina.

Windows PowerShell, com ferramentas já instaladas:

```powershell
$env:QF_PLAYWRIGHT_MODULE = 'C:/caminho/ferramentas/node_modules/playwright-core/index.mjs'
$env:QF_BROWSER_PATH = 'C:/Program Files/Google/Chrome/Application/chrome.exe'
npm run test:platform-browser
```

O caminho real do navegador deve ser conferido. As validações disponíveis não certificam execução do produto em Windows real.

## Recuperar o histórico Git portátil

O ZIP inclui o snapshot legível em `quadrinha/` e o bundle `historico/quadrinha-main.bundle`. Não é necessário usar o bundle para abrir/ler o código no Claude Code, mas ele preserva os commits anteriores.

Para ter um clone local com histórico sem depender da rede, a partir da pasta extraída do pacote:

```bash
git clone --branch main historico/quadrinha-main.bundle quadrinha-com-historico
cd quadrinha-com-historico
git remote set-url origin https://github.com/lmdsistemas-lmd/quadrinha.git
git log --oneline
```

Depois copie os documentos de continuidade do snapshot `quadrinha/` para o clone, preservando o `.git` do clone e quaisquer alterações que você tenha feito. O bundle contém somente arquivos versionados até o commit-base, não os novos documentos da exportação nem dados ignorados.

Alternativa online:

```bash
git clone https://github.com/lmdsistemas-lmd/quadrinha.git
```

O projeto pode ter avançado depois da exportação. Antes de sobrepor arquivos do snapshot, confira commits e alterações. A exportação contém um estado datado, não uma sincronização futura automática. Não usar `reset --hard`, `git clean` ou sobrescrita cega para igualar os arquivos.

## Migrar os dados de uma instalação existente

O ZIP não inclui seus bancos, chave local, segredos ou contas de acesso. Para transferir uma instalação com registros:

1. Identifique qual modo e diretório a instalação realmente usa: SaaS `PLATFORM_DATA_DIR` ou standalone `QF_DATABASE_PATH`/padrões.
2. Pare de forma controlada apenas o processo que usa esses bancos. Não encerre aplicações alheias por uma porta coincidente.
3. Faça backup privado de TODO o diretório de dados relevante, incluindo bancos, WAL/SHM existentes e `platform.key` correspondente, se for o caso.
4. Se a chave vier de `PLATFORM_ENCRYPTION_KEY`, preserve seu valor por canal privado/gerenciador de segredos. Uma chave diferente torna as credenciais existentes ilegíveis.
5. Transfira `.env` privado apenas por meio seguro, separado do pacote de conversa/código. Adapte caminhos e endereço público ao novo host.
6. Restaure numa cópia, inicie com a mesma modalidade e confira autenticação, acesso por empresa, quantidades e histórico financeiro antes de usar como instalação principal.
7. Guarde o backup anterior até verificar restauração e integridade. Não excluir o original por causa de erro de inicialização.

Não copie apenas o arquivo principal de SQLite com o serviço gravando. Não interprete ausência de cadastros numa instalação nova como perda do código: dados e código são artefatos diferentes. Não há migração automática standalone → SaaS no snapshot.

## Referência visual e material externo

Origem autorizada: https://sistema.quadrafacil.com.br/. O proprietário informou ter somente acesso web. Observações anteriores foram read-only. O código novo e os testes não precisam de login no original para instalar/rodar.

No ambiente antigo, o material autenticado ficava em `/workspace/scratch/quadrafacil`. Ele não foi copiado para a exportação. Documentos como `levantamento.md`, `audit-reference-ui.mjs` e capturas/DOM privados podem não estar disponíveis na nova máquina. O que foi preservado de modo portátil: perfis de UI, assets públicos locais, medidas e documentos de fidelidade e screenshots da nova aplicação com dados fictícios.

Se precisar de nova comparação, combinar acesso autorizado seguro com o proprietário. Não pedir senha no prompt. O original já redirecionou para renovação, portanto nem toda tela pode estar acessível atualmente; não tentar renovar ou gravar dados para obter acesso.

## Ambiente em nuvem anterior

- O checkout da aplicação era `/workspace/quadrinha`; REA separado em `/workspace/reamy`; um checkout antigo independente ficava em `/workspace/quadrafacil-novo`.
- Toolchain preparada em `/workspace/.reamy-toolchain/node_modules/.bin` com Node 24.18.0/npm 11.16.0; cache npm em `/workspace/.npm-cache`.
- Configuração de instalação/inicialização do ambiente havia sido salva em rascunho para revisão/publicação. Isso não significa que a aplicação foi hospedada nem que a configuração foi publicada posteriormente.
- O rascunho de egress personalizado incluía api.mercadopago.com, graph.facebook.com, sistema.quadrafacil.com.br, cdnjs.cloudflare.com, www.google.com e www.gstatic.com, mais o preset de gerenciadores de pacotes; a publicação dessa lista não foi confirmada.
- Credenciais de acesso ao original eram identificadas como QUADRAFACIL_EMAIL e QUADRAFACIL_SENHA; seus valores/bindings não foram exportados e não são necessários para iniciar a nova aplicação.
- Nenhum token/secret de provedor real ou domínio público foi confirmado como funcional. Não transportar placeholders de proxy como se fossem valores de criptografia/HMAC.
- Scripts e a preparação local substituem a necessidade de ferramentas proprietárias do ambiente anterior. Para destino novo, configurar HTTPS, persistência, segredos e rede na hospedagem escolhida.
