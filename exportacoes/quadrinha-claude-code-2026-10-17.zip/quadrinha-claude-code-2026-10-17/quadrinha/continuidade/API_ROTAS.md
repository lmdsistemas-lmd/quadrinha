# Mapa da API para continuidade

Este mapa descreve a versão exportada. Consulte os handlers reais antes de gerar clientes/migrações. Mutação autenticada requer cookie de sessão e `X-CSRF-Token`; requisições de navegador também passam pela validação de origem. Webhooks são autenticados por assinatura do provedor. Respostas privadas usam no-store.

## Plataforma e autenticação

| Método | Rota | Conteúdo/responsabilidade |
| --- | --- | --- |
| GET | `/api/session` | Usuário seguro, csrf, empresas, smtpConfigured, domainConfigured e localUrl |
| GET | `/api/plans` | Somente planos publicados |
| POST | `/api/auth/register` | Nome, email, password, company, slug e referral opcional; cria arena/owner e coloca verificação na fila |
| POST | `/api/auth/login` | Email/password; exige conta ativa/verificada; cria cookie e devolve csrf |
| POST | `/api/auth/consume` | token, purpose (`verify`, `reset`, `invite`); password quando necessário |
| POST | `/api/auth/forgot` | Recuperação por email |
| POST | `/api/auth/resend` | Nova confirmação por email |
| POST | `/api/auth/logout` | Revoga sessão |
| GET | `/api/subscriptions` | Empresas acessíveis à conta, planos e compras/charges permitidas |
| POST | `/api/subscriptions/checkout` | tenantId e planId; somente administrador associado à empresa, mesmo se gestão estiver bloqueada |

Nenhum campo `superadmin`, `verified` ou papel privilegiado recebido do cadastro público concede permissão.

## Administração da plataforma

Todas as rotas abaixo requerem superadministrador, além de sessão/CSRF quando aplicável.

| Método | Rota | Conteúdo/responsabilidade |
| --- | --- | --- |
| GET | `/api/admin/overview` | Empresas, planos, charges, readiness, estados públicos das integrações, fila e auditoria |
| POST | `/api/admin/plans` | name, amountCents, periodMonths, courtLimit, published, description |
| PUT | `/api/admin/plans/{id}` | Atualiza e incrementa versão sem reescrever snapshots de compras |
| POST | `/api/admin/tenants/{uuid}/access` | mode: manual, disabled ou subscription |
| POST | `/api/admin/tenants/{uuid}/reset-owner` | Envia recuperação ao proprietário; não devolve senha/token |
| GET/PUT | `/api/admin/integrations/smtp` | Campos de configuração SMTP; senha só escrita, indicadores na leitura |
| GET/PUT | `/api/admin/integrations/mercadopago` | environment, enabled, accessToken, webhookSecret; segredos não são lidos de volta |
| POST | `/api/admin/integrations/{smtp|mercadopago}/verify` | Valida conexão real quando configurada; testes injetam transporte |
| POST | `/api/admin/integrations/smtp/flush` | Processa fila elegível |
| PUT | `/api/admin/finance` | accountName e installments; conta interna de recebimentos de planos |
| GET | `/api/admin/payments` | Faturas e histórico de pagamento da plataforma |
| POST | `/api/admin/payments/reconcile` | paymentId, consulta autenticada ao MP |

## Gestão da arena

Prefixo: `/app/{slug}/api`. Requer sessão de plataforma, membership ativa e empresa com acesso liberado. Rotas de configuração privada exigem administrador da arena. Consulta não pode mutar dados.

| Método | Sufixo | Conteúdo/responsabilidade |
| --- | --- | --- |
| GET | `/session` | Sessão de gestão mapeada, csrf, managed=true |
| GET | `/bootstrap` | Módulos, settings, usuário, faturas/eventos permitidos e relatórios da arena |
| POST | `/logout` | Logout central |
| GET | `/tenant` | Identificação da arena e portal |
| GET/PUT | `/integrations/{mercadopago|whatsapp}` | Configuração por UUID interno, sem devolver valores secretos |
| POST | `/integrations/{mercadopago|whatsapp}/verify` | Conta MP ou número Meta |
| POST | `/integrations/whatsapp/send` | phone internacional + consent=true; template é o aprovado configurado |
| GET | `/whatsapp-messages` | Últimos estados dos envios da arena |
| GET/PUT | `/portal` | published, title, description, address, phone, color e duration |
| GET | `/notifications` | Notificações da arena/usuário |
| GET | `/referrals` | Código, link quando público, contador e rewardEnabled=false |
| GET/POST | `/records/usuarios` | Lista de memberships/convite, não criação de senha local arbitrária |
| PUT/DELETE | `/records/usuarios/{id}` | Papel/ativação ou desativação, preservando proprietário e acesso próprio |
| GET/POST | `/records/{modulo}` | Operações de registros conforme contracts/permissions |
| GET/PUT/DELETE | `/records/{modulo}/{id}` | Registro da própria arena, com validação e exclusão lógica quando permitida |
| GET/PUT | `/finance/config` | Readiness e conta/parcelas |
| POST | `/finance/verify` | Valida merchant MP |
| POST | `/payments/checkout` | module + recordId; valor nunca vem livre do navegador |
| POST | `/payments/reconcile` | paymentId da conta correspondente |
| PUT | `/settings/{key}` | Configuração definida em modules.mjs; não é cofre de credenciais |
| POST | `/reports` | Gera retrato CSV com filtros permitidos |
| GET/DELETE | `/reports/{id}` | Download/exclusão do arquivo da arena |
| POST | `/memberships/generate` | Mensalidades dos sócios para period YYYY-MM, idempotentes |
| POST | `/products/import` | records com itens de produto, importação atômica |

`/setup` e `/login` do motor standalone não concedem acesso ao SaaS. Não expor um listener standalone associado ao banco de um tenant para contornar o hub.

## Jogador

Prefixo: `/reservar/{slug}/api`. Arena deve estar ativa/acessível e portal publicado; caso contrário 404. Sessão do jogador é diferente da gestão.

| Método | Sufixo | Conteúdo/responsabilidade |
| --- | --- | --- |
| GET | `/session` | Usuário seguro/csrf, dados públicos da arena |
| POST | `/register` | name, email, password; conta daquela arena |
| POST | `/login` | email/password verificados |
| POST | `/forgot`, `/resend` | Fluxos de e-mail próprios do jogador |
| GET | `/availability?date=YYYY-MM-DD` | Quadras/slots/tarifa/preço em centavos e paymentReady |
| GET | `/bookings` | Somente reservas próprias |
| POST | `/bookings` | date, courtId, tariffId, start, idempotencyKey, notes opcional; preço/fim são definidos pelo servidor |
| POST | `/bookings/{id}/checkout` | Somente a própria reserva pendente; usa credencial da arena |
| POST | `/bookings/{id}/reconcile` | paymentId já identificado e associado; não é consulta pública de IDs arbitrários |
| POST | `/logout` | Revoga cookie do jogador |

A confirmação/reset usa a rota comum de consumo de token; o token persistido define a conta correta, não um tenant livre escolhido no consumo.

## Webhooks

| Método | Rota | Validação |
| --- | --- | --- |
| POST | `/api/platform/webhooks/mercadopago?data.id={id}` | x-signature + x-request-id + secret da plataforma; consulta API e atualiza vigência |
| POST | `/app/{slug}/api/webhooks/mercadopago?data.id={id}` | Mesma validação com secret e merchant da arena |
| GET | `/api/whatsapp/{uuid-ou-platform}` | Challenge Meta com verifyToken configurado |
| POST | `/api/whatsapp/{uuid-ou-platform}` | Corpo bruto + x-hub-signature-256, appSecret, número e message ID no escopo |

O MP usa corpo `{type:"payment", data:{id:...}}` correspondente à query. Retorno do checkout no navegador não é webhook e não baixa status. Não passar tokens nos parâmetros da URL de checkout/portal.

## Contratos complementares

- `CONTRATOS_MODULOS.json`: todos os módulos, campos, opções e referências da versão.
- `SCHEMA_MASTER.sql`: tabelas/índices do mestre e das integrações.
- `SCHEMA_EMPRESA.sql`: tabelas/índices de motor e financeiro.
- Tipos de status da fatura: creating, pending, paid, review, refunded, partially_refunded, charged_back.
- Status de origem financeira são rótulos do domínio, por exemplo Pendente/Recebido/Cancelado/Estornado; não substituí-los por enum externo sem revisar sincronização.
