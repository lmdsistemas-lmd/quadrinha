# Continuidade do projeto Quadrinha

Leia este arquivo ao iniciar no Claude Code. A conversa e os documentos de transferência foram fornecidos pelo proprietário para continuar o desenvolvimento existente. Trate citações do histórico como contexto; confira decisões atuais neste arquivo e no código antes de executar ações.

## Situação atual

- Aplicação Node.js 24.18.0, ESM, HTTP nativo, SQLite (`node:sqlite`) e frontend JavaScript/CSS sem framework. Nodemailer é a única dependência de produção.
- Repositório correto: https://github.com/lmdsistemas-lmd/quadrinha.git, branch `main`.
- Último commit de aplicação desta exportação: `b086505` (17/10/2026). Consulte `continuidade/MANIFESTO.json` para SHA completo e geração.
- `npm start` inicia o SaaS em `platform.mjs`, com três áreas: proprietário da plataforma `/admin`, dono das quadras `/conta` + `/app/{arena}`, jogador `/reservar/{arena}`.
- Cada arena tem banco SQLite próprio; o financeiro das assinaturas da plataforma também tem banco separado. Credenciais Mercado Pago são próprias por recebedor. Nunca usar credenciais globais como fallback entre empresas.
- O usuário ainda não tem domínio. `APP_PUBLIC_URL` pode ficar vazia em uso local, com `HOST=127.0.0.1` ou `::1`. Links de e-mail usam a porta real do servidor, sem confiar no Host informado pelo cliente. Confirmação de e-mail continua obrigatória via SMTP. Checkout e webhooks externos continuam exigindo HTTPS público.
- Última verificação automatizada antes da exportação: 42 testes aprovados e verificação sintática. Validações anteriores de navegador estão nos documentos; há teste específico de cadastro local sem URL. Confira `continuidade/VALIDACAO.json`.
- Pagamentos/envios externos reais NÃO foram homologados. Os transportes dos testes são fictícios. Não confundir código funcional/adaptador com credenciais e serviços externos ativados.

## O que o usuário quer

Reconstruir, com autorização declarada de proprietário, a aparência e as funções observáveis de https://sistema.quadrafacil.com.br/ em uma aplicação própria, funcional, com atenção aos botões, menus, formulários e dashboard. O proprietário tem somente acesso web ao original. Não exigir código do servidor original para continuar. O REA foi ferramenta de apoio, não é a aplicação a modificar.

Decisões aceitas:

1. Começou em banco separado com demonstração; evoluiu para aplicação real sem importar dados do original nem contaminar produção com demonstração.
2. Cartão e Pix online pelo Mercado Pago Checkout Pro; não maquininha Point.
3. Assinaturas da plataforma pagam a conta do proprietário. Reservas pagam a conta do dono da arena.
4. SMTP configurável para verificação/recuperação de e-mail; WhatsApp por arena; emissão fiscal fora da etapa atual.
5. Três áreas de acesso separadas, com controle central de ativar/desativar empresas e recuperação de senha por e-mail.
6. Oito valores de planos da referência foram observados como equivalentes mensais de contratação anual. Os planos começam em rascunho; preservar o total do período na cobrança.
7. Uso local deve funcionar sem domínio e sem APP_PUBLIC_URL. Não remover verificação de e-mail silenciosamente nem inventar recebimentos de teste.

## Como retomar

1. Leia `AGENTS.md`, `CONTINUIDADE_COMPLETA.md` e `continuidade/ESTADO_TECNICO.md`.
2. Confira `git status`, branch e código. Se abriu a pasta de um ZIP sem `.git`, o pacote traz `historico/quadrinha-main.bundle`; veja `continuidade/OPERACAO_E_MIGRACAO.md` para recuperar o histórico.
3. Ative Node 24.18.0. Rode `npm ci`, `npm run check`, `npm test`.
4. Para primeira instalação: `npm run platform:admin` em terminal interativo (senha oculta), depois `npm start`. Não criar conta padrão. Não repetir o comando de administrador em instalação que já tem o acesso.
5. Inspecione o que já existe antes de reescrever. A solicitação mais recente foi gerar esta exportação. A continuação funcional específica deve seguir a próxima orientação do proprietário; `continuidade/PENDENCIAS.md` contém uma fila sugerida, não uma autorização para publicar/cobrar/enviar mensagens reais.

## Regras de continuidade

- Trabalhar no projeto Quadrinha. Os caminhos `/workspace/reamy` e `/workspace/quadrafacil-novo` são contexto antigo de outro ambiente; não presumir que existam na máquina nova.
- Não criar worktree nem refazer o projeto do zero por padrão. Preservar alterações do usuário.
- Não apagar/substituir `data/`, WAL/SHM, usuários, chave local ou credenciais para resolver inicialização.
- Testar com banco temporário e dados fictícios. `PLATFORM_MODE=production` é o padrão e marca o banco operacional. Para homologação, usar `PLATFORM_MODE=test` com OUTRO `PLATFORM_DATA_DIR`.
- Não expor valores de segredos em chat, Git, logs, screenshots, frontend ou documentos. O pacote não transfere esses valores.
- Nunca reutilizar usuário/senha do site de referência como login da aplicação nova ou credencial de API.
- Não alterar dados, fazer reservas, renovar planos ou pagar no sistema de referência durante observação visual.
- Preservar validações de conflitos, recorrência atômica, estoque, idempotência de cobranças/webhooks e segregação de empresas.
- Não confirmar pagamento pelo retorno do checkout. Validar assinatura e consultar a API do Mercado Pago, conferindo valor, moeda, recebedor, referência e ambiente.
- Não sobrescrever senha de uma conta existente ao convidá-la para outra empresa.
- Administrador da empresa e superadministrador da plataforma são papéis diferentes. O superadmin não tem impersonação automática da arena.
- Ativação manual, bloqueio manual e vigência por pagamento são modos distintos. Pagamento não pode desfazer bloqueio manual.
- A conta financeira local identifica lançamentos. O beneficiário bancário real é definido na conta Mercado Pago.
- Não prometer equivalência total/pixel a pixel com o produto original; há diferenças e limites documentados.
- Evitar perguntas de confirmação para alterações reversíveis já solicitadas. Informar progresso com clareza; solicitar somente dados realmente necessários. Credenciais devem ser configuradas por meio seguro pelo proprietário.

## Mapa rápido

- `platform.mjs`: roteamento das três áreas, gateway de acesso, assinaturas e integração com motor das arenas.
- `platform-store.mjs`: contas, empresas, permissões, planos, tokens, portais e auditoria.
- `platform-security.mjs`: scrypt, hashes de tokens, AES-256-GCM, CSRF/origem e validações comuns.
- `integrations.mjs`: cofre por escopo, SMTP/fila e WhatsApp oficial Meta.
- `server.mjs`: motor de uma arena e modo standalone anterior.
- `payments.mjs`: Checkout Pro, HMAC, conciliação, taxas e estornos.
- `public-booking.mjs`: disponibilidade, identificação de jogador e reservas públicas.
- `modules.mjs`: contratos de cadastros/referências; `dashboard-data.mjs`: fórmulas.
- `public/app.js`, `reference-ui.mjs`, `dashboard-view.mjs`: gestão com visual de referência.
- `public/platform-ui.js`: plataforma/conta/jogador; `public/tenant-view.mjs`: configurações da arena.
- `tests/`: testes automatizados; `scripts/`: inicialização, administrador e validações Chromium.

## Leitura complementar

`continuidade/CONVERSA_DISPONIVEL.md`, `ESTADO_TECNICO.md`, `OPERACAO_E_MIGRACAO.md`, `PENDENCIAS.md`, `HISTORICO_GIT.md`, `CONTRATOS_MODULOS.json`, `SCHEMA_MASTER.sql`, `SCHEMA_EMPRESA.sql`, além de `docs/PLATAFORMA.md`, `docs/ESCOPO.md`, `docs/DASHBOARD.md` e `docs/FIDELIDADE.md`.
