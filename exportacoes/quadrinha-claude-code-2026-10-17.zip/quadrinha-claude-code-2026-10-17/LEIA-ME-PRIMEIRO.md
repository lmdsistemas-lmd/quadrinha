# Exportação para continuar no Claude Code

Esta exportação reúne o projeto Quadrinha, a conversa disponível, decisões, arquitetura, estado de implementação, testes, pendências, instruções de instalação e histórico Git da aplicação. Preparada em 17/10/2026, com datas apresentadas ao usuário no fuso America/Sao_Paulo.

## Usar agora

1. Extraia o ZIP completo.
2. Abra a pasta `quadrinha` no terminal/Claude Code.
3. Cole o texto de `PROMPT_PARA_CLAUDE.txt` na primeira interação. O `CLAUDE.md` na raiz também orienta a leitura automática.
4. A IA deverá conferir `AGENTS.md`, o estado técnico e os testes antes de alterar a aplicação.

Se quiser carregar somente um documento na outra IA, use **`CONTINUIDADE_COMPLETA.md`**. Ele combina os documentos de contexto; o ZIP também inclui o código e os assets que esse documento não substitui.

## Organização do pacote

| Caminho | Conteúdo |
| --- | --- |
| `quadrinha/` | Snapshot dos arquivos versionados do projeto, acrescido desta documentação de continuidade |
| `quadrinha/CLAUDE.md` | Orientações para Claude Code na raiz do projeto |
| `quadrinha/CONTINUIDADE_COMPLETA.md` | Documento único com contexto, conversa disponível e instruções técnicas |
| `quadrinha/continuidade/` | Documentos detalhados, schemas SQL, contratos JSON e evidências de validação |
| `historico/quadrinha-main.bundle` | Histórico Git da branch main até o commit-base; não contém dados locais ignorados |
| `MANIFESTO_EXPORTACAO.json` | Commit-base, arquivos, tamanhos e limites da exportação |
| `SHA256SUMS.txt` | Integridade dos arquivos do pacote |

O snapshot de aplicação é o commit `b086505`; a documentação de continuidade foi gerada à parte e adicionada ao pacote. O bundle preserva o histórico da aplicação até esse commit. Os documentos novos da exportação não fazem parte daquele commit e aparecerão como arquivos adicionais se forem copiados para um clone recuperado pelo bundle.

## Alcance da conversa

O histórico exportado reproduz as mensagens do usuário e respostas finais do assistente que estavam disponíveis neste contexto. Respostas antigas que só sobreviveram como resumo estão identificadas como tal. A imagem enviada pelo usuário é descrita; o arquivo binário original do anexo não estava disponível como arquivo local. Datas individuais não conhecidas não foram inventadas.

Isto não é uma extração integral garantida do banco de conversas do ChatGPT. Não existe acesso, a partir desta tarefa, a mensagens antigas indisponíveis na janela atual ou à exportação oficial da conta. Para uma transcrição integral exata do aplicativo, pode ser necessário usar separadamente a exportação de dados da conta que contém o chat.

## Dados preservados separadamente

O pacote é portátil e não inclui `.env` privado, credenciais, bancos de uso local, `platform.key`, cookies/sessões, capturas autenticadas do site original, caches, `node_modules` ou a pasta `.git` ativa. O histórico Git está no bundle.

Para preservar cadastros/usuários existentes na sua instalação, siga o procedimento de backup privado em `continuidade/OPERACAO_E_MIGRACAO.md`. Sem esse backup, a nova instalação começa com seus próprios bancos vazios. O código, a documentação e o histórico Git incluídos são suficientes para continuar o desenvolvimento; contas e serviços externos precisam de configuração própria na nova máquina.
